<?php

namespace App\Repository;

use App\Entity\Group;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\ORM\Exception\ORMException;
use Doctrine\ORM\OptimisticLockException;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<Group>
 *
 * @method Group|null find($id, $lockMode = null, $lockVersion = null)
 * @method Group|null findOneBy(array $criteria, array $orderBy = null)
 * @method Group[]    findAll()
 * @method Group[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class GroupRepository extends ServiceEntityRepository
{

    public function listing($filter = null, $search=null,  $page, $itemPerPage, $sort )
    {
        $firstResult = ($page - 1) * $itemPerPage;
        $qb = $this->createQueryBuilder('se');
        if ($search != null) {
            //  dump($search); exit;l
            $g = 0;
            foreach ($search['attr'] as $attrs) {
                $qb
                    ->orWhere('se.' . $attrs . ' like :searchval_' . $g);
                $qb->setParameter(
                    'searchval_' . $g, '%' . $search['value'] . '%'
                );
                $g++;
            }

        }
        $qb2 = $this->createQueryBuilder('u');
        if ($filter and $filter != null) {
            $i = 0;
            foreach ($filter as $f) {
                switch ($f['op']) {
                    case 'eq':
                        $qb2
                            ->andWhere('u.' . $f['attr'] . ' = :value_' . $i)
                            ->setParameter('value_' . $i, $f['value']);
                        break;

                    case 'lk':
                        $qb2
                            ->andWhere('u.' . $f['attr'] . ' like :value_' . $i)
                            ->setParameter('value_' . $i, '%' . $f['value'] . '%');
                        break;
                    case 'gt':
                        $qb2
                            ->andWhere('u.' . $f['attr'] . ' > :value_' . $i)
                            ->setParameter('value_' . $i, $f['value']);
                        break;
                    case 'gte':
                        $qb2
                            ->andWhere('u.' . $f['attr'] . ' >= :value_' . $i)
                            ->setParameter('value_' . $i, $f['value']);
                        break;
                    case 'lt':
                        $qb2->andWhere('u.' . $f['attr'] . ' < :value_' . $i)
                            ->setParameter('value_' . $i, $f['value']);
                        break;
                    case 'lte':
                        $qb2
                            ->andWhere('u.' . $f['attr'] . ' <= :value_' . $i)
                            ->setParameter('value_' . $i, $f['value']);
                        break;
                    case 'nt':
                        $qb2
                            ->andWhere('u.' . $f['attr'] . ' <> :value_' . $i)
                            ->setParameter('value_' . $i, $f['value']);;
                        break;
                }
                $i++;
            }

        }
        //dd($qb->getQuery()->getResult()); exit;
        $qb2->andWhere($qb2->expr()->in(
            'u.id',
            $qb->getDQL()
        ));

        if ($sort != null) {
            $qb2->orderBy('u.' . $sort['attr'], $sort['ordre']);
        } else {
            $qb2->orderBy('u.id', 'DESC');
        }


        $result = $qb2->getQuery();


       // dd($qb2->getQuery()->getResult());
       // exit;


        $paginator = new \Doctrine\ORM\Tools\Pagination\Paginator($result);
        $totalItems = count($paginator);
        $pagesCount = ceil($totalItems / $itemPerPage);

        $paginator
            ->getQuery()
            ->setFirstResult($itemPerPage * ($page - 1)) // set the offset
            ->setMaxResults($itemPerPage); // set the limit

        return ['data' => $paginator, 'totalItems' => $totalItems, 'totalPages' => $pagesCount];
    }
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Group::class);
    }

    /**
     * @throws ORMException
     * @throws OptimisticLockException
     */
    public function add(Group $entity, bool $flush = false): void
    {
        $this->_em->persist($entity);
        if ($flush) {
            $this->_em->flush();
        }
    }

    /**
     * @throws ORMException
     * @throws OptimisticLockException
     */
    public function remove(Group $entity, bool $flush = false): void
    {
        $this->_em->remove($entity);
        if ($flush) {
            $this->_em->flush();
        }
    }

//    /**
//     * @return Group[] Returns an array of Group objects
//     */
//    public function findByExampleField($value): array
//    {
//        return $this->createQueryBuilder('g')
//            ->andWhere('g.exampleField = :val')
//            ->setParameter('val', $value)
//            ->orderBy('g.id', 'ASC')
//            ->setMaxResults(10)
//            ->getQuery()
//            ->getResult()
//        ;
//    }

//    public function findOneBySomeField($value): ?Group
//    {
//        return $this->createQueryBuilder('g')
//            ->andWhere('g.exampleField = :val')
//            ->setParameter('val', $value)
//            ->getQuery()
//            ->getOneOrNullResult()
//        ;
//    }
}
