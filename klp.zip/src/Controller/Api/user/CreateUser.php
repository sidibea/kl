<?php

namespace App\Controller\Api\user;

use App\Entity\User;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;
use Symfony\Component\Security\Core\Encoder\UserPasswordEncoderInterface;

class CreateUser
{
    protected $em;
    protected $request;
    protected $encoder;


    public function __construct(EntityManagerInterface $em,  UserPasswordHasherInterface $passwordHasher)
    {
        $this->em = $em;
        $this->encoder = $passwordHasher;

    }
    public function __invoke(User $data, \Symfony\Component\HttpFoundation\Request $request)
    {
        //dump($data); exit;
        // hash the password (based on the security.yaml config for the $user class)
        $hashedPassword = $this->encoder->hashPassword(
            $data,
            $data->getPassword()
        );
        $data->setPassword($hashedPassword);

        $this->em->persist($data);
        $this->em->flush();


        return $data;



    }

}