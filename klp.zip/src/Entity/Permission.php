<?php

namespace App\Entity;

use ApiPlatform\Core\Annotation\ApiResource;
use App\Repository\PermissionRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: PermissionRepository::class)]
#[ApiResource(
    attributes: ["route_prefix"=>"/v2", "pagination_client_items_per_page"=>true]
)]
class Permission
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private $id;

    #[ORM\ManyToOne(targetEntity: Group::class, inversedBy: 'permissions')]
    private $role;

    #[ORM\Column(type: 'string', length: 255)]
    private $permission;

    #[ORM\ManyToOne(targetEntity: Navigation::class, inversedBy: 'navigationPermissions')]
    private $navigation;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getRole(): ?Group
    {
        return $this->role;
    }

    public function setRole(?Group $role): self
    {
        $this->role = $role;

        return $this;
    }

    public function getPermission(): ?string
    {
        return $this->permission;
    }

    public function setPermission(string $permission): self
    {
        $this->permission = $permission;

        return $this;
    }

    public function getNavigation(): ?Navigation
    {
        return $this->navigation;
    }

    public function setNavigation(?Navigation $navigation): self
    {
        $this->navigation = $navigation;

        return $this;
    }
}
