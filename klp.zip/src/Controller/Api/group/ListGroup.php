<?php

namespace App\Controller\Api\group;

use App\Entity\Group;
use App\Entity\User;
use Doctrine\ORM\EntityManagerInterface;

class ListGroup
{
    protected $em;
    protected $request;
    protected $encoder;

    public function __construct(EntityManagerInterface $em)
    {
        $this->em = $em;
    }

    public function __invoke( \Symfony\Component\HttpFoundation\Request $request)
    {
        $filter = ($request->get('filter'))?$request->get('filter'):null;
        $search = ($request->get('search'))?$request->get('search'):null;
        $page = ($request->get('page'))?$request->get('page'):1;
        $itemPerPage = ($request->get('itemPerPage'))?$request->get('itemPerPage'):30;
        $sort = ($request->get('sort'))?$request->get('sort'):null;
        $list = $this->em->getRepository(Group::class)->listing($filter, $search, $page, $itemPerPage, $sort);

        return $list;
    }

}