<?php

namespace App\Repository;

use App\Entity\Entite;
use App\Entity\User;
use App\Repository\AbstractRepository;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\ORM\Exception\ORMException;
use Doctrine\ORM\OptimisticLockException;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<Entite>
 *
 * @method Entite|null find($id, $lockMode = null, $lockVersion = null)
 * @method Entite|null findOneBy(array $criteria, array $orderBy = null)
 * @method Entite[]    findAll()
 * @method Entite[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class EntiteRepository extends AbstractRepository
{
    public function listing( $filter = null, $search=null, $page, $itemPerPage, $sort){
        return $this->quering($this->createQueryBuilder('u'),$filter, $search, $page, $itemPerPage, $sort);
    }



}
