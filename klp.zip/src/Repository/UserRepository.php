<?php

namespace App\Repository;

use ApiPlatform\Core\Bridge\Doctrine\Orm\Paginator;
use App\Entity\User;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Common\Collections\Criteria;
use Doctrine\ORM\Exception\ORMException;
use Doctrine\ORM\OptimisticLockException;
use Doctrine\ORM\QueryBuilder;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<User>
 *
 * @method User|null find($id, $lockMode = null, $lockVersion = null)
 * @method User|null findOneBy(array $criteria, array $orderBy = null)
 * @method User[]    findAll()
 * @method User[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class UserRepository extends ServiceEntityRepository
{

    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, User::class);
    }

    public function listing($filter = null, $search=null,  $page, $itemPerPage, $sort )
    {
        $firstResult = ($page -1) * $itemPerPage;
        $qb = $this->createQueryBuilder('se');
        if($search != null){
            //  dump($search); exit;l
            $g = 0;
            foreach ($search['attr'] as $attrs){
                $qb
                    ->orWhere('se.'.$attrs.' like %'. $search['value'].'%'  );

                $g++;
            }

        }
        $qb2 = $this->createQueryBuilder('u');
        if($filter and $filter != null)
        {
            $i=0;
            foreach($filter as $f){
                switch ($f['op']){
                    case 'eq':
                        $qb2
                            ->andWhere('u.'.$f['attr'].' = :value_'.$i)
                            ->setParameter('value_'.$i, $f['value']);
                        break;

                    case 'lk':
                        $qb2
                            ->andWhere('u.'.$f['attr'].' like :value_'.$i)
                            ->setParameter('value_'.$i, '%'.$f['value'].'%');
                        break;
                    case 'gt':
                        $qb2
                            ->andWhere('u.'.$f['attr'].' > :value_'.$i)
                            ->setParameter('value_'.$i, $f['value']);
                        break;
                    case 'gte':
                        $qb2
                            ->andWhere('u.'.$f['attr'].' >= :value_'.$i)
                            ->setParameter('value_'.$i, $f['value']);
                        break;
                    case 'lt':
                        $qb2->andWhere('u.'.$f['attr'].' < :value_'.$i)
                            ->setParameter('value_'.$i, $f['value']);
                        break;
                    case 'lte':
                        $qb2
                            ->andWhere('u.'.$f['attr'].' <= :value_'.$i)
                            ->setParameter('value_'.$i, $f['value']);
                        break;
                    case 'nt':
                        $qb2
                            ->andWhere('u.'.$f['attr'].' <> :value_'.$i)
                            ->setParameter('value_'.$i, $f['value']);;
                        break;
                }
                $i++;
            }

        }
        //dd($qb->getQuery()->getResult()); exit;
        $qb2->andWhere($qb2->expr()->in(
            'u.id',
            $qb->getDQL()
        ));

        if($sort != null){
            $qb2->orderBy('u.'.$sort['attr'], $sort['ordre']);
        }else{
            $qb2->orderBy('u.id', 'DESC');
        }







        $result = $qb2->getQuery();


       // dd($qb2->getQuery()->getResult()); exit;




        $paginator = new \Doctrine\ORM\Tools\Pagination\Paginator($result);
        $totalItems = count($paginator);
        $pagesCount = ceil($totalItems / $itemPerPage);

        $paginator
            ->getQuery()
            ->setFirstResult($itemPerPage * ($page-1)) // set the offset
            ->setMaxResults($itemPerPage); // set the limit

        return ['data' => $paginator, 'totalItems'=>$totalItems, 'totalPages'=>$pagesCount];

    }



}
