<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20220517170927 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE entite (id INT AUTO_INCREMENT NOT NULL, ville_id INT DEFAULT NULL, pays_id INT DEFAULT NULL, type_id INT DEFAULT NULL, nom VARCHAR(255) NOT NULL, code VARCHAR(255) NOT NULL, statut_juridique VARCHAR(255) NOT NULL, adresse VARCHAR(255) DEFAULT NULL, commission NUMERIC(10, 2) NOT NULL, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL COMMENT \'(DC2Type:datetime_immutable)\', enabled TINYINT(1) NOT NULL, INDEX IDX_1A291827A73F0036 (ville_id), INDEX IDX_1A291827A6E44244 (pays_id), INDEX IDX_1A291827C54C8C93 (type_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE pays (id INT AUTO_INCREMENT NOT NULL, nom VARCHAR(255) NOT NULL, iso VARCHAR(255) NOT NULL, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE ramification (id INT AUTO_INCREMENT NOT NULL, type_id INT DEFAULT NULL, parent_id INT DEFAULT NULL, entite_id INT DEFAULT NULL, nom VARCHAR(255) NOT NULL, code VARCHAR(255) NOT NULL, ordre INT NOT NULL, enabled TINYINT(1) NOT NULL, cptr_equip INT NOT NULL, cptr_contrib INT NOT NULL, INDEX IDX_3F8B5793C54C8C93 (type_id), INDEX IDX_3F8B5793727ACA70 (parent_id), INDEX IDX_3F8B57939BEA957A (entite_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE type_entite (id INT AUTO_INCREMENT NOT NULL, nom VARCHAR(255) NOT NULL, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE type_ramification (id INT AUTO_INCREMENT NOT NULL, nom VARCHAR(255) NOT NULL, ordre VARCHAR(255) NOT NULL, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL, enabled TINYINT(1) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE ville (id INT AUTO_INCREMENT NOT NULL, pays_id INT DEFAULT NULL, nom VARCHAR(255) NOT NULL, iso VARCHAR(255) DEFAULT NULL, enabled TINYINT(1) NOT NULL, created_at DATETIME NOT NULL, update_at DATETIME NOT NULL, INDEX IDX_43C3D9C3A6E44244 (pays_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE entite ADD CONSTRAINT FK_1A291827A73F0036 FOREIGN KEY (ville_id) REFERENCES ville (id)');
        $this->addSql('ALTER TABLE entite ADD CONSTRAINT FK_1A291827A6E44244 FOREIGN KEY (pays_id) REFERENCES pays (id)');
        $this->addSql('ALTER TABLE entite ADD CONSTRAINT FK_1A291827C54C8C93 FOREIGN KEY (type_id) REFERENCES type_entite (id)');
        $this->addSql('ALTER TABLE ramification ADD CONSTRAINT FK_3F8B5793C54C8C93 FOREIGN KEY (type_id) REFERENCES type_ramification (id)');
        $this->addSql('ALTER TABLE ramification ADD CONSTRAINT FK_3F8B5793727ACA70 FOREIGN KEY (parent_id) REFERENCES ramification (id)');
        $this->addSql('ALTER TABLE ramification ADD CONSTRAINT FK_3F8B57939BEA957A FOREIGN KEY (entite_id) REFERENCES entite (id)');
        $this->addSql('ALTER TABLE ville ADD CONSTRAINT FK_43C3D9C3A6E44244 FOREIGN KEY (pays_id) REFERENCES pays (id)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE ramification DROP FOREIGN KEY FK_3F8B57939BEA957A');
        $this->addSql('ALTER TABLE entite DROP FOREIGN KEY FK_1A291827A6E44244');
        $this->addSql('ALTER TABLE ville DROP FOREIGN KEY FK_43C3D9C3A6E44244');
        $this->addSql('ALTER TABLE ramification DROP FOREIGN KEY FK_3F8B5793727ACA70');
        $this->addSql('ALTER TABLE entite DROP FOREIGN KEY FK_1A291827C54C8C93');
        $this->addSql('ALTER TABLE ramification DROP FOREIGN KEY FK_3F8B5793C54C8C93');
        $this->addSql('ALTER TABLE entite DROP FOREIGN KEY FK_1A291827A73F0036');
        $this->addSql('DROP TABLE entite');
        $this->addSql('DROP TABLE pays');
        $this->addSql('DROP TABLE ramification');
        $this->addSql('DROP TABLE type_entite');
        $this->addSql('DROP TABLE type_ramification');
        $this->addSql('DROP TABLE ville');
    }
}
