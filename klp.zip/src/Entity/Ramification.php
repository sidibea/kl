<?php

namespace App\Entity;

use ApiPlatform\Core\Annotation\ApiResource;
use App\Repository\RamificationRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: RamificationRepository::class)]
#[ApiResource]
class Ramification
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private $id;

    #[ORM\Column(type: 'string', length: 255)]
    private $nom;

    #[ORM\ManyToOne(targetEntity: TypeRamification::class, inversedBy: 'ramifications')]
    private $type;

    #[ORM\Column(type: 'string', length: 255)]
    private $code;

    #[ORM\Column(type: 'integer', length: 255)]
    private $ordre;

    #[ORM\ManyToOne(targetEntity: self::class, inversedBy: 'ramifications')]
    private $parent;

    #[ORM\OneToMany(mappedBy: 'parent', targetEntity: self::class)]
    private $ramifications;

    #[ORM\ManyToOne(targetEntity: Entite::class, inversedBy: 'ramifications')]
    private $entite;

    #[ORM\Column(type: 'boolean')]
    private $enabled;

    #[ORM\Column(type: 'integer')]
    private $cptrEquip;

    #[ORM\Column(type: 'integer')]
    private $cptrContrib;

    public function __construct()
    {
        $this->ramifications = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    public function getType(): ?TypeRamification
    {
        return $this->type;
    }

    public function setType(?TypeRamification $type): self
    {
        $this->type = $type;

        return $this;
    }

    public function getCode(): ?string
    {
        return $this->code;
    }

    public function setCode(string $code): self
    {
        $this->code = $code;

        return $this;
    }

    public function getOrdre(): ?int
    {
        return $this->ordre;
    }

    public function setOrdre(int $ordre): self
    {
        $this->ordre = $ordre;

        return $this;
    }

    public function getParent(): ?self
    {
        return $this->parent;
    }

    public function setParent(?self $parent): self
    {
        $this->parent = $parent;

        return $this;
    }

    /**
     * @return Collection<int, self>
     */
    public function getRamifications(): Collection
    {
        return $this->ramifications;
    }

    public function addRamification(self $ramification): self
    {
        if (!$this->ramifications->contains($ramification)) {
            $this->ramifications[] = $ramification;
            $ramification->setParent($this);
        }

        return $this;
    }

    public function removeRamification(self $ramification): self
    {
        if ($this->ramifications->removeElement($ramification)) {
            // set the owning side to null (unless already changed)
            if ($ramification->getParent() === $this) {
                $ramification->setParent(null);
            }
        }

        return $this;
    }

    public function getEntite(): ?Entite
    {
        return $this->entite;
    }

    public function setEntite(?Entite $entite): self
    {
        $this->entite = $entite;

        return $this;
    }

    public function getEnabled(): ?bool
    {
        return $this->enabled;
    }

    public function setEnabled(bool $enabled): self
    {
        $this->enabled = $enabled;

        return $this;
    }

    public function getCptrEquip(): ?int
    {
        return $this->cptrEquip;
    }

    public function setCptrEquip(int $cptrEquip): self
    {
        $this->cptrEquip = $cptrEquip;

        return $this;
    }

    public function getCptrContrib(): ?int
    {
        return $this->cptrContrib;
    }

    public function setCptrContrib(int $cptrContrib): self
    {
        $this->cptrContrib = $cptrContrib;

        return $this;
    }
}
