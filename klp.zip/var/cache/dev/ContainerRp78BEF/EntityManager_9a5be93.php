<?php

namespace ContainerRp78BEF;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'src'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder60021 = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializer02bfd = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties8e6f3 = [
        
    ];

    public function getConnection()
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'getConnection', array(), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'getMetadataFactory', array(), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'getExpressionBuilder', array(), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'beginTransaction', array(), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->beginTransaction();
    }

    public function getCache()
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'getCache', array(), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->getCache();
    }

    public function transactional($func)
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'transactional', array('func' => $func), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'wrapInTransaction', array('func' => $func), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'commit', array(), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->commit();
    }

    public function rollback()
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'rollback', array(), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'getClassMetadata', array('className' => $className), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'createQuery', array('dql' => $dql), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'createNamedQuery', array('name' => $name), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'createQueryBuilder', array(), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'flush', array('entity' => $entity), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'clear', array('entityName' => $entityName), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->clear($entityName);
    }

    public function close()
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'close', array(), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->close();
    }

    public function persist($entity)
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'persist', array('entity' => $entity), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'remove', array('entity' => $entity), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'refresh', array('entity' => $entity), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'detach', array('entity' => $entity), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'merge', array('entity' => $entity), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'getRepository', array('entityName' => $entityName), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'contains', array('entity' => $entity), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'getEventManager', array(), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'getConfiguration', array(), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'isOpen', array(), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'getUnitOfWork', array(), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'getProxyFactory', array(), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'initializeObject', array('obj' => $obj), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'getFilters', array(), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'isFiltersStateClean', array(), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'hasFilters', array(), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return $this->valueHolder60021->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializer02bfd = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolder60021) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder60021 = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder60021->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, '__get', ['name' => $name], $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        if (isset(self::$publicProperties8e6f3[$name])) {
            return $this->valueHolder60021->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder60021;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder60021;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, '__set', array('name' => $name, 'value' => $value), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder60021;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder60021;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, '__isset', array('name' => $name), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder60021;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder60021;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, '__unset', array('name' => $name), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder60021;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder60021;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, '__clone', array(), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        $this->valueHolder60021 = clone $this->valueHolder60021;
    }

    public function __sleep()
    {
        $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, '__sleep', array(), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;

        return array('valueHolder60021');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializer02bfd = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializer02bfd;
    }

    public function initializeProxy() : bool
    {
        return $this->initializer02bfd && ($this->initializer02bfd->__invoke($valueHolder60021, $this, 'initializeProxy', array(), $this->initializer02bfd) || 1) && $this->valueHolder60021 = $valueHolder60021;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder60021;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder60021;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
