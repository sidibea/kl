<?php

namespace App\Controller\Api\user;

use Doctrine\ORM\EntityManagerInterface;
use Knp\Component\Pager\PaginatorInterface;

class SearchUser
{
    protected $em;
    protected $request;
    protected $encoder;

    public function __construct(EntityManagerInterface $em)
    {
        $this->em = $em;

    }

    public function __invoke( \Symfony\Component\HttpFoundation\Request $request, PaginatorInterface $paginator)
    {

    }

}