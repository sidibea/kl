<?php

namespace App\Repository;

use App\Entity\User;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\ORM\QueryBuilder;
use Doctrine\Persistence\ManagerRegistry;

abstract class AbstractRepository extends ServiceEntityRepository
{
    const ITEMS_PER_PAGE = 20;

    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, User::class);
    }


    public function quering(QueryBuilder $qb, $filter = null, $search=null,  $page, $itemPerPage, $sort )
    {
        $firstResult = ($page -1) * $itemPerPage;


        if($filter and $filter != null)
        {
            $i=0;
            foreach($filter as $f){
                switch ($f['op']){
                    case 'eq':
                        $qb
                            ->andWhere('u.'.$f['attr'].' = :value_'.$i)
                            ->setParameter('value_'.$i, $f['value']);
                        break;

                    case 'lk':
                        $qb
                            ->andWhere('u.'.$f['attr'].' like :value_'.$i)
                            ->setParameter('value_'.$i, '%'.$f['value'].'%');
                        break;
                    case 'gt':
                        $qb
                            ->andWhere('u.'.$f['attr'].' > :value_'.$i)
                            ->setParameter('value_'.$i, $f['value']);
                        break;
                    case 'gte':
                        $qb
                            ->andWhere('u.'.$f['attr'].' >= :value_'.$i)
                            ->setParameter('value_'.$i, $f['value']);
                        break;
                    case 'lt':
                        $qb->andWhere('u.'.$f['attr'].' < :value_'.$i)
                            ->setParameter('value_'.$i, $f['value']);
                        break;
                    case 'lte':
                        $qb
                            ->andWhere('u.'.$f['attr'].' <= :value_'.$i)
                            ->setParameter('value_'.$i, $f['value']);
                        break;
                    case 'nt':
                        $qb
                            ->andWhere('u.'.$f['attr'].' <> :value_'.$i)
                            ->setParameter('value_'.$i, $f['value']);;
                        break;
                }
                $i++;
            }


        }

        $qb2 = $this->createQueryBuilder('qb');

        if($search != null){
          //  dump($search); exit;
            $qb2
                ->where('qb.'.$search['attr'].' = :searchval' );

        }
        $qb2->setParameters([
            'searchval'=> $search['value']
        ]);

        $qb->where($qb->expr()->in(
            'u.id',
            $qb2->getDQL()
        ));

        if($sort != null){
            $qb->orderBy('u.'.$sort['attr'], $sort['ordre']);
        }else{
            $qb->orderBy('u.id', 'DESC');
        }
        $result = $qb->getQuery();






        $paginator = new \Doctrine\ORM\Tools\Pagination\Paginator($result);
        $totalItems = count($paginator);
        $pagesCount = ceil($totalItems / $itemPerPage);

        $paginator
            ->getQuery()
            ->setFirstResult($itemPerPage * ($page-1)) // set the offset
            ->setMaxResults($itemPerPage); // set the limit

        return ['data' => $paginator, 'totalItems'=>$totalItems, 'totalPages'=>$pagesCount];

    }


}