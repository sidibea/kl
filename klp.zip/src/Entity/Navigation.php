<?php

namespace App\Entity;

use ApiPlatform\Core\Annotation\ApiResource;
use App\Repository\NavigationRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: NavigationRepository::class)]
#[ApiResource(
    attributes: ["route_prefix"=>"/v2", "pagination_client_items_per_page"=>true]
)]
class Navigation
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private $id;

    #[ORM\Column(type: 'string', length: 255)]
    private $nom;

    #[ORM\Column(type: 'string', length: 255, nullable: true)]
    private $icon;

    #[ORM\Column(type: 'string', length: 255, nullable: true)]
    private $url;

    #[ORM\ManyToOne(targetEntity: self::class)]
    private $parent;

    #[ORM\OneToMany(mappedBy: 'navigation', targetEntity: Permission::class)]
    private $navigationPermissions;

    #[ORM\Column(type: 'string', length: 255)]
    private $module;

    #[ORM\Column(type: 'array')]
    private $permission = [];

    public function __construct()
    {
        $this->navigationPermissions = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    public function getIcon(): ?string
    {
        return $this->icon;
    }

    public function setIcon(?string $icon): self
    {
        $this->icon = $icon;

        return $this;
    }

    public function getUrl(): ?string
    {
        return $this->url;
    }

    public function setUrl(?string $url): self
    {
        $this->url = $url;

        return $this;
    }

    public function getParent(): ?self
    {
        return $this->parent;
    }

    public function setParent(?self $parent): self
    {
        $this->parent = $parent;

        return $this;
    }

    /**
     * @return Collection<int, Permission>
     */
    public function getNavigationPermissions(): Collection
    {
        return $this->navigationPermissions;
    }

    public function addNavigationPermission(Permission $navigationPermission): self
    {
        if (!$this->navigationPermissions->contains($navigationPermission)) {
            $this->navigationPermissions[] = $navigationPermission;
            $navigationPermission->setNavigation($this);
        }

        return $this;
    }

    public function removeNavigationPermission(Permission $navigationPermission): self
    {
        if ($this->navigationPermissions->removeElement($navigationPermission)) {
            // set the owning side to null (unless already changed)
            if ($navigationPermission->getNavigation() === $this) {
                $navigationPermission->setNavigation(null);
            }
        }

        return $this;
    }

    public function getModule(): ?string
    {
        return $this->module;
    }

    public function setModule(string $module): self
    {
        $this->module = $module;

        return $this;
    }

    public function getPermission(): ?array
    {
        return $this->permission;
    }

    public function setPermission(array $permission): self
    {
        $this->permission = $permission;

        return $this;
    }
}
