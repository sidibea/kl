<?php

namespace App\Entity;

use ApiPlatform\Core\Annotation\ApiResource;
use App\Controller\Api\user\CreateUser;
use App\Controller\Api\user\ListEntite;
use App\Controller\Api\user\ListUser;
use App\Repository\EntiteRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: EntiteRepository::class)]
#[ApiResource(
    collectionOperations: [
        'list_users' => [
            'method' => 'GET',
            'path' => '/entites',
            'controller' => ListEntite::class,
        ]
    ],
    attributes: ["route_prefix"=>"/v2", "pagination_client_items_per_page"=>true]
)]
class Entite
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private $id;

    #[ORM\Column(type: 'string', length: 255)]
    private $nom;

    #[ORM\Column(type: 'string', length: 255)]
    private $code;

    #[ORM\ManyToOne(targetEntity: Ville::class, inversedBy: 'entites')]
    private $ville;

    #[ORM\ManyToOne(targetEntity: Pays::class, inversedBy: 'entites')]
    private $pays;

    #[ORM\Column(type: 'string', length: 255)]
    private $statutJuridique;

    #[ORM\Column(type: 'string', length: 255, nullable: true)]
    private $adresse;

    #[ORM\ManyToOne(targetEntity: TypeEntite::class, inversedBy: 'entites')]
    private $type;

    #[ORM\Column(type: 'decimal', precision: 10, scale: 2)]
    private $commission;

    #[ORM\Column(type: 'datetime')]
    private $createdAt;

    #[ORM\Column(type: 'datetime_immutable')]
    private $updatedAt;

    #[ORM\Column(type: 'boolean')]
    private $enabled;

    #[ORM\OneToMany(mappedBy: 'entite', targetEntity: Ramification::class)]
    private $ramifications;

    public function __construct()
    {
        $this->ramifications = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    public function getCode(): ?string
    {
        return $this->code;
    }

    public function setCode(string $code): self
    {
        $this->code = $code;

        return $this;
    }

    public function getVille(): ?Ville
    {
        return $this->ville;
    }

    public function setVille(?Ville $ville): self
    {
        $this->ville = $ville;

        return $this;
    }

    public function getPays(): ?Pays
    {
        return $this->pays;
    }

    public function setPays(?Pays $pays): self
    {
        $this->pays = $pays;

        return $this;
    }

    public function getStatutJuridique(): ?string
    {
        return $this->statutJuridique;
    }

    public function setStatutJuridique(string $statutJuridique): self
    {
        $this->statutJuridique = $statutJuridique;

        return $this;
    }

    public function getAdresse(): ?string
    {
        return $this->adresse;
    }

    public function setAdresse(?string $adresse): self
    {
        $this->adresse = $adresse;

        return $this;
    }

    public function getType(): ?TypeEntite
    {
        return $this->type;
    }

    public function setType(?TypeEntite $type): self
    {
        $this->type = $type;

        return $this;
    }

    public function getCommission(): ?string
    {
        return $this->commission;
    }

    public function setCommission(string $commission): self
    {
        $this->commission = $commission;

        return $this;
    }

    public function getCreatedAt(): ?\DateTimeInterface
    {
        return $this->createdAt;
    }

    public function setCreatedAt(\DateTimeInterface $createdAt): self
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    public function getUpdatedAt(): ?\DateTimeImmutable
    {
        return $this->updatedAt;
    }

    public function setUpdatedAt(\DateTimeImmutable $updatedAt): self
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    public function getEnabled(): ?bool
    {
        return $this->enabled;
    }

    public function setEnabled(bool $enabled): self
    {
        $this->enabled = $enabled;

        return $this;
    }

    /**
     * @return Collection<int, Ramification>
     */
    public function getRamifications(): Collection
    {
        return $this->ramifications;
    }

    public function addRamification(Ramification $ramification): self
    {
        if (!$this->ramifications->contains($ramification)) {
            $this->ramifications[] = $ramification;
            $ramification->setEntite($this);
        }

        return $this;
    }

    public function removeRamification(Ramification $ramification): self
    {
        if ($this->ramifications->removeElement($ramification)) {
            // set the owning side to null (unless already changed)
            if ($ramification->getEntite() === $this) {
                $ramification->setEntite(null);
            }
        }

        return $this;
    }
}
